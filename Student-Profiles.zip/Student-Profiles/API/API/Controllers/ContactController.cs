using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Main;
using API.ContactModule;
using Microsoft.AspNetCore.Http; // Required for StatusCodes

namespace API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContactController : ControllerBase
    {
        // *** FIX: Depend on the interface, not the concrete class. ***
        private readonly IContactRepository _repository;

        // *** FIX: Inject the interface in the constructor. ***
        public ContactController(IContactRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// Gets all contacts.
        /// </summary>
        //[Authorize(Policy = "UserAccess")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<Contact>>> GetAll()
        {
            var result = await _repository.GetAllAsync();
            return Ok(result);
        }

        /// <summary>
        /// Gets a specific contact by their ID.
        /// </summary>
        /// <param name="id">The ID of the contact.</param>
        //[Authorize(Policy = "UserAccess")]
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Contact>> GetById(int id)
        {
            var item = await _repository.GetByIdAsync(id);
            var contact = item?.FirstOrDefault(); // GetByIdAsync returns IEnumerable
            if (contact == null)
            {
                return NotFound($"No contact found with ID: {id}");
            }
            return Ok(contact);
        }

        /// <summary>
        /// Searches for contacts by name.
        /// </summary>
        //[Authorize(Policy = "UserAccess")]
        [HttpGet("search-by-name")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<Contact>>> GetByName([FromQuery] string name)
        {
            var items = await _repository.GetByNameAsync(name);
            return Ok(items);
        }

        /// <summary>
        /// Searches for contacts across all fields.
        /// </summary>
        /// <param name="query">The search term.</param>
        //[Authorize(Policy = "UserAccess")]
        [HttpGet("search-all")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<Contact>>> SearchAll([FromQuery] string query)
        {
            var result = await _repository.SearchAsync(query);
            return Ok(result);
        }

        /// <summary>
        /// Gets a paginated list of contacts.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of records per page.</param>
        //[Authorize(Policy = "UserAccess")]
        [HttpGet("paginated")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<PaginationModel<Contact>>> GetPaginated([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 25)
        {
            var pagedResult = await _repository.GetPaginatedAsync(pageNumber, pageSize);
            return Ok(pagedResult);
        }

        /// <summary>
        /// Creates a new contact.
        /// </summary>
        /// <param name="entity">The contact object to create.</param>
        //[Authorize(Policy = "ModAccess")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Create([FromBody] Contact entity)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _repository.AddAsync(entity);
            // Returns a 201 Created status with a link to the newly created resource
            return CreatedAtAction(nameof(GetById), new { id = entity.ID }, entity);
        }

        /// <summary>
        /// Updates an existing contact.
        /// </summary>
        /// <param name="id">The ID of the contact to update.</param>
        /// <param name="entity">The updated contact object.</param>
        //[Authorize(Policy = "ModAccess")]
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Update(int id, [FromBody] Contact entity)
        {
            if (id != entity.ID)
            {
                return BadRequest("ID mismatch between route and body.");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            await _repository.UpdateAsync(entity);
            return NoContent(); // Standard response for a successful update
        }

        /// <summary>
        /// Deletes a contact by their ID.
        /// </summary>
        /// <param name="id">The ID of the contact to delete.</param>
        //[Authorize(Policy = "AdminAccess")]
        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> Delete(int id)
        {
            await _repository.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// Deletes all contacts.
        /// </summary>
        //[Authorize(Policy = "AdminAccess")]
        [HttpDelete("delete-all")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> DeleteAll()
        {
            await _repository.DeleteAllAsync();
            return NoContent();
        }

        /// <summary>
        /// Uploads a list of contacts in bulk.
        /// </summary>
        /// <param name="dataList">The list of contacts to upload.</param>
        //[Authorize(Policy = "ModAccess")]
        [HttpPost("bulk-upload")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> BulkUpload([FromBody] List<Contact> dataList)
        {
            if (dataList == null || !dataList.Any())
            {
                return BadRequest("Data list cannot be null or empty.");
            }

            await _repository.BulkUploadAsync(dataList);
            return Ok(new { message = $"Successfully uploaded {dataList.Count} contact records." });
        }
    }
}