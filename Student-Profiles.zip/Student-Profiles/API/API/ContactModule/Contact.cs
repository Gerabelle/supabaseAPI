﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using API.Main;

namespace API.ContactModule 
{

    [Table("contact")]
    public class Contact
    {
        private int? _id;
        private string? _name;
        private string? _gender;
        private DateTime? _birthday;
        private string? _address;
        private string? _contactNum;

        private string? _email;
        private string? _major;

        [Column("id")]
        public int ID
        {
            get => _id ?? 0;
            set => _id = value;
        }

        [Column("name")]
        public string Name
        {
            get => _name ?? string.Empty;
            set => _name = value;
        }

        [Column("gender")]
        public string Gender
        {
            get => _gender ?? string.Empty;
            set => _gender = value;
        }

        [Column("birthday")]
        public DateTime Birthday
        {
            get => _birthday ?? DateTime.MinValue;
            set => _birthday = value;
        }

        [Column("address")]
        public string Address
        {
            get => _address ?? string.Empty;
            set => _address = value;
        }

        [Column("contact_num")]
        public string ContactNum
        {
            get => _contactNum ?? string.Empty;
            set => _contactNum = value;
        }

        [Column("email")]
        public string Email
        {
            get => _email ?? string.Empty;
            set => _email = value;
        }
        
        [Column("major")]
        public string Major
        {
            get => _major ?? string.Empty;
            set => _major = value;
        }
    }
}