﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.Common;
using Npgsql;
using API.Main;

namespace API.ContactModule 
{

    public class ContactRepository : BaseRepository, IContactRepository
    {
        public ContactRepository(MyCon dbConnection) : base(dbConnection) { }


        private Contact MapReaderToContact(DbDataReader reader)
        {
            return new Contact()
            {
                ID = reader.IsDBNull(reader.GetOrdinal("id")) ? 0 : reader.GetInt32(reader.GetOrdinal("id")),
                Name = reader.IsDBNull(reader.GetOrdinal("name")) ? string.Empty : reader.GetString(reader.GetOrdinal("name")),
                Gender = reader.IsDBNull(reader.GetOrdinal("gender")) ? string.Empty : reader.GetString(reader.GetOrdinal("gender")),
                Birthday = reader.IsDBNull(reader.GetOrdinal("birthday")) ? DateTime.MinValue : reader.GetDateTime(reader.GetOrdinal("birthday")),
                Address = reader.IsDBNull(reader.GetOrdinal("address")) ? string.Empty : reader.GetString(reader.GetOrdinal("address")),
                ContactNum = reader.IsDBNull(reader.GetOrdinal("contact_num")) ? string.Empty : reader.GetString(reader.GetOrdinal("contact_num")),
                Email = reader.IsDBNull(reader.GetOrdinal("email")) ? string.Empty : reader.GetString(reader.GetOrdinal("email")),
                Major = reader.IsDBNull(reader.GetOrdinal("major")) ? string.Empty : reader.GetString(reader.GetOrdinal("major"))
            };
        }


        private const string TableName = "\"student_profiles\"";

        public async Task<IEnumerable<Contact>> GetAllAsync()
        {
            return await ExecuteReaderToListAsync($"SELECT * FROM {TableName}", MapReaderToContact);
        }

        public async Task<IEnumerable<Contact>> GetByIdAsync(int id)
        {
            return await ExecuteReaderToListAsync($"SELECT * FROM {TableName} WHERE \"id\" = @id", MapReaderToContact, new[] { CreateParameter("@id", id) });
        }


        public async Task<IEnumerable<Contact>> GetByNameAsync(string name)
        {
            return await ExecuteReaderToListAsync($"SELECT * FROM {TableName} WHERE \"name\" ILIKE @name", MapReaderToContact, new[] { CreateParameter("@name", "%" + name + "%") });
        }

        public async Task AddAsync(Contact entity)
        {
            var sql = $"INSERT INTO {TableName} (\"name\", \"gender\", \"birthday\", \"address\", \"contact_num\", \"email\", \"major\") VALUES (@Name, @Gender, @Birthday, @Address, @ContactNum, @Email, @Major)";
            var dbParameters = new List<DbParameter>
            {
                CreateParameter("@Name", entity.Name),
                CreateParameter("@Gender", entity.Gender),
                CreateParameter("@Birthday", entity.Birthday),
                CreateParameter("@Address", entity.Address),
                CreateParameter("@ContactNum", entity.ContactNum),
                CreateParameter("@Email", entity.Email),
                CreateParameter("@Major", entity.Major)
            };
            await ExecuteNonQueryAsync(sql, dbParameters.ToArray());
        }

        public async Task UpdateAsync(Contact entity)
        {
            var sql = $"UPDATE {TableName} SET \"name\" = @Name, \"gender\" = @Gender, \"birthday\" = @Birthday, \"address\" = @Address, \"contact_num\", \"email\", \"major\" = @ContactNum WHERE \"id\" = @id";
            var dbParameters = new List<DbParameter>
            {
                CreateParameter("@id", entity.ID),
                CreateParameter("@Name", entity.Name),
                CreateParameter("@Gender", entity.Gender),
                CreateParameter("@Birthday", entity.Birthday),
                CreateParameter("@Address", entity.Address),
                CreateParameter("@ContactNum", entity.ContactNum),
                CreateParameter("@Email", entity.Email),
                CreateParameter("@Major", entity.Major)
            };
            await ExecuteNonQueryAsync(sql, dbParameters.ToArray());
        }

        public async Task DeleteAsync(int id)
        {
            await ExecuteNonQueryAsync($"DELETE FROM {TableName} WHERE \"id\" = @id", new[] { CreateParameter("@id", id) });
        }

        public async Task<PaginationModel<Contact>> GetPaginatedAsync(int pageNumber, int pageSize)
        {
            if (pageSize <= 0)
            {
                var allItems = await GetAllAsync();
                return new PaginationModel<Contact>(allItems, allItems.Count(), 1, pageSize);
            }

            string sql = $"SELECT * FROM {TableName} ORDER BY \"id\" LIMIT @pageSize OFFSET @offset";
            var items = await ExecuteReaderToListAsync(sql, MapReaderToContact, new DbParameter[]
            {
                CreateParameter("@pageSize", pageSize),
                CreateParameter("@offset", (pageNumber - 1) * pageSize)
            });

            var totalRecordsCount = await ExecuteScalarAsync<long>($"SELECT COUNT(*) FROM {TableName}");
            return new PaginationModel<Contact>(items, (int)totalRecordsCount, pageNumber, pageSize);
        }

        public async Task<IEnumerable<Contact>> SearchAsync(string query)
        {
            var filters = new List<string>
            {
                "CAST(\"id\" AS TEXT) ILIKE @query", "\"name\" ILIKE @query", "\"gender\" ILIKE @query",
                "to_char(\"birthday\", 'YYYY-MM-DD') ILIKE @query", "\"address\" ILIKE @query", "\"contact_num\" ILIKE @query", "\"email\" ILIKE @query", "\"major\" ILIKE @query"
            };
            string sql = $"SELECT * FROM {TableName} WHERE {string.Join(" OR ", filters)}";
            return await ExecuteReaderToListAsync(sql, MapReaderToContact, new[] { CreateParameter("@query", "%" + query + "%") });
        }

        public Task DeleteAllAsync() => ExecuteNonQueryAsync($"TRUNCATE TABLE {TableName}");
        public async Task BulkUploadAsync(List<Contact> dataList) { foreach (var item in dataList) await AddAsync(item); }
        public Task<IEnumerable<Contact>> GetByGenderAsync(string gender) => throw new NotImplementedException();
        public Task<IEnumerable<Contact>> GetByBirthdayAsync(DateTime birthday) => throw new NotImplementedException();
        public Task<IEnumerable<Contact>> GetByAddressAsync(string address) => throw new NotImplementedException();
        public Task<IEnumerable<Contact>> GetByContactnumAsync(string contactnum) => throw new NotImplementedException();
        public Task<IEnumerable<Contact>> GetByEmailAsync(string email) => throw new NotImplementedException();
        public Task<IEnumerable<Contact>> GetByMajorAsync(string major) => throw new NotImplementedException();
    }
}