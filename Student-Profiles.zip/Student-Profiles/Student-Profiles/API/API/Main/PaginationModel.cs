﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace API.Main
{
    public class PaginationModel<T>
    {
        public List<T> Items { get; set; }
        public int TotalCount { get; set; }
        public int PageSize { get; set; }
        public int CurrentPage { get; set; }

        // *** FIX: Prevent division by zero when PageSize is 0 or less. ***
        public int TotalPages
        {
            get
            {
                if (TotalCount <= 0 || PageSize <= 0)
                {
                    // If there are no records or pagination is disabled, there's only one "page" (or zero).
                    return 1;
                }
                return (int)Math.Ceiling(TotalCount / (double)PageSize);
            }
        }

        public bool HasPreviousPage => CurrentPage > 1;
        public bool HasNextPage => CurrentPage < TotalPages;

        public PaginationModel()
        {
            Items = new List<T>();
            // Initialize with safe defaults
            TotalCount = 0;
            CurrentPage = 1;
            PageSize = 1;
        }

        public PaginationModel(IEnumerable<T> items, int totalCount, int currentPage, int pageSize)
        {
            Items = items.ToList();
            TotalCount = totalCount;
            CurrentPage = currentPage;
            PageSize = pageSize;
        }
    }
}