﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Threading.Tasks;
using Npgsql;

namespace API.Main
{
    public abstract class BaseRepository
    {
        protected readonly MyCon _dbConnection;

        protected BaseRepository(MyCon dbConnection)
        {
            _dbConnection = dbConnection ?? throw new ArgumentNullException(nameof(dbConnection));
        }

        protected async Task<T?> ExecuteScalarAsync<T>(string query, params DbParameter[] parameters)
        {
            await using var connection = _dbConnection.GetConnection();
            await using var command = connection.CreateCommand();

            command.CommandText = query;
            if (parameters != null)
                command.Parameters.AddRange(parameters);

            await connection.OpenAsync();
            var result = await command.ExecuteScalarAsync();

            if (result == null || result == DBNull.Value)
            {
                return default(T);
            }

            return (T)Convert.ChangeType(result, typeof(T));
        }

        protected async Task<int> ExecuteNonQueryAsync(string query, params DbParameter[] parameters)
        {
            await using var connection = _dbConnection.GetConnection();
            await using var command = connection.CreateCommand();

            command.CommandText = query;
            if (parameters != null)
                command.Parameters.AddRange(parameters);

            await connection.OpenAsync();
            return await command.ExecuteNonQueryAsync();
        }

        protected async Task<List<T>> ExecuteReaderToListAsync<T>(string query, Func<DbDataReader, T> mapper, params DbParameter[] parameters)
        {
            var result = new List<T>();
            await using var connection = _dbConnection.GetConnection();
            await using var command = connection.CreateCommand();

            command.CommandText = query;
            if (parameters != null)
                command.Parameters.AddRange(parameters);

            await connection.OpenAsync();
            await using var reader = await command.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                result.Add(mapper(reader));
            }

            return result;
        }

        protected DbParameter CreateParameter(string name, object value)
        {
            return new NpgsqlParameter(name, value ?? DBNull.Value);
        }
    }
}