﻿using System;
using System.Data.Common;
using Npgsql;

namespace API.Main
{
    public class MyCon
    {
        private readonly string connectionString;

        public MyCon()
        {
            
            connectionString = "Host=aws-0-ap-southeast-1.pooler.supabase.com;" + 
                "Port=5432;" +
                "Database=postgres;" +
                "Username=postgres.uhdyovrkewtsnwdwfblo;" +
                "Password=gerabelleAnne_05;" + 
                "SSL Mode=Require;" +
                "Trust Server Certificate=True;";
        }

        public DbConnection GetConnection()
        {
            try
            {
                var connection = new NpgsqlConnection(connectionString);
                return connection;
            }
            catch (DbException ex)
            {
                throw new InvalidOperationException($"Database error: {ex.Message}", ex);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Unexpected error: {ex.Message}", ex);
            }
        }
    }
}