﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using API.Main;

namespace API.ContactModule 
{

    public interface IContactRepository
    {
        Task<IEnumerable<Contact>> GetAllAsync();
        Task AddAsync(Contact entity);
        Task UpdateAsync(Contact entity);
        Task DeleteAsync(int id);
        Task DeleteAllAsync();
        Task<IEnumerable<Contact>> SearchAsync(string query);
        Task<PaginationModel<Contact>> GetPaginatedAsync(int pageNumber, int pageSize);
        Task BulkUploadAsync(List<Contact> dataList);
        Task<IEnumerable<Contact>> GetByIdAsync(int id);
        Task<IEnumerable<Contact>> GetByNameAsync(string name);
        Task<IEnumerable<Contact>> GetByGenderAsync(string gender);
        Task<IEnumerable<Contact>> GetByBirthdayAsync(DateTime birthday);
        Task<IEnumerable<Contact>> GetByAddressAsync(string address);
        Task<IEnumerable<Contact>> GetByContactnumAsync(string contactnum);
        Task<IEnumerable<Contact>> GetByEmailAsync(string email);
        Task<IEnumerable<Contact>> GetByMajorAsync(string major);
    }
}