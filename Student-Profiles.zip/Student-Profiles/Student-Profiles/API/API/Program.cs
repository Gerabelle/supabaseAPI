using API.ContactModule;
using API.Main;

// Define a name for your CORS policy
var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

var builder = WebApplication.CreateBuilder(args);

// --- START OF SERVICE CONFIGURATION ---

// *** FIX 1: Add the CORS policy definition. ***
// This policy is very open, which is fine for development.
// It allows any web origin, any method (GET, POST, etc.), and any header to access your API.
builder.Services.AddCors(options =>
{
    options.AddPolicy(name: MyAllowSpecificOrigins,
                      policy =>
                      {
                          policy.AllowAnyOrigin()
                                .AllowAnyHeader()
                                .AllowAnyMethod();
                      });
});

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<MyCon>();
builder.Services.AddScoped<IContactRepository, ContactRepository>();

// --- END OF SERVICE CONFIGURATION ---

var app = builder.Build();

// --- START OF HTTP PIPELINE CONFIGURATION ---

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// *** FIX 2: Apply the CORS policy to your application's pipeline. ***
// This MUST be placed after UseRouting (which is implicitly added) and before UseAuthorization.
app.UseCors(MyAllowSpecificOrigins);

app.UseAuthorization();

app.MapControllers();

// --- END OF HTTP PIPELINE CONFIGURATION ---

app.Run();